﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickCampus_Core.Common.Enum
{
    public enum CompanyEnum
    {
        BrainTechnosys = 1,
        AriaTelecom = 2,

    }
}
