﻿using QuickCampus_DAL.Context;

namespace QuickCampus_Core.Interfaces
{
    public interface IClientRepo : IGenericRepository<TblClient>
    {
       
    }
}
