﻿using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using QuickCampus_DAL.Context;
using System.ComponentModel.DataAnnotations;

namespace QuickCampus_Core.ViewModel
{
    public class ClientVM

    {
        public static explicit operator ClientVM(TblClient items)
        {
            return new ClientVM
            {
                Id = items.Id,
                Name = items.Name,
                CraetedBy = items.CraetedBy ?? 0,
                CreatedDate = items.CreatedDate,
                ModifiedBy = items.ModifiedBy,
                ModofiedDate = items.ModofiedDate,
                Address = items.Address,
                Phone= items.Phone,
                Email = items.Email,
                SubscriptionPlan = items.SubscriptionPlan,
                Geolocation = items.Geolocation,
            };
        }
        public int Id { get; set; }

        [Remote("IsAlreadyExist", "Client", HttpMethod = "POST", ErrorMessage = "Name already exists in database.")]
        public string? Name { get; set; }

       public int? CraetedBy { get; set; }

       public DateTime? CreatedDate { get; set; }

       public int? ModifiedBy { get; set; }

        public DateTime? ModofiedDate { get; set; }
        public string? Address { get; set; }
        [Required]
        [RegularExpression(@"^[1-9][0-9]{9}$", ErrorMessage = "Please enter a valid 10-digit mobile number that does not start with 0.")]
        public string? Phone { get; set; }

        public string? Email { get; set; }

        public string? Geolocation { get; set; }

        public string? SubscriptionPlan { get; set; }

        public TblClient ToClientDbModel()
        {
            return new TblClient
            {
                Name = Name,
                Phone = Phone,
                Email = Email,
                Geolocation = Geolocation,
                SubscriptionPlan = SubscriptionPlan,
                ModifiedBy = ModifiedBy,
                ModofiedDate = (DateTime)(Id >0? ModofiedDate : null),
                CraetedBy = CraetedBy,
                Address = Address,
                CreatedDate = (DateTime)(Id < 0 ? CreatedDate : null),
                IsActive = true,
                IsDeleted = false,
            };
        }

        public TblClient ToUpdateDbModel()
        {
            return new TblClient
            {
                Id = Id,
                Name = Name,
                Phone = Phone,
                Email = Email,
                SubscriptionPlan = SubscriptionPlan,
                Geolocation = Geolocation,
                ModifiedBy = ModifiedBy,
                ModofiedDate = (DateTime)ModofiedDate,
                CraetedBy = CraetedBy,
                Address = Address,
                CreatedDate = (DateTime)CreatedDate,
                IsActive = true,
                IsDeleted = false,
            };
        }

        public class ClientValidator : AbstractValidator<ClientVM>
        {
            public ClientValidator()
            {
                RuleFor(x => x.Name)
                     .Cascade(CascadeMode.StopOnFirstFailure)
                  .NotNull().WithMessage("Name could not be null")

                  .NotEmpty().WithMessage("Name could not be empty")
            .Matches(@"^[A-Za-z\s]*$").WithMessage("'{PropertyName}' should only contain letters.")
            .Length(3, 30);
                RuleFor(x => x.Address)
                  .Cascade(CascadeMode.StopOnFirstFailure)
                  .NotNull().WithMessage("Address could not be null")
                  .NotEmpty().WithMessage("Address could not be empty")
                  .Length(0, 100).WithMessage("Address lengh could not be greater than 100");

                RuleFor(x => x.Phone)
                  .Cascade(CascadeMode.StopOnFirstFailure)
                  .NotNull().WithMessage("Phone could not be null")
                  .NotEmpty().WithMessage("Phone could not be empty");

                RuleFor(x => x.Email)
                  .Cascade(CascadeMode.StopOnFirstFailure).EmailAddress()
                  .NotNull().WithMessage("Email could not be null")
                  .NotEmpty().WithMessage("Email could not be empty");


                RuleFor(x => x.SubscriptionPlan)
                  .Cascade(CascadeMode.StopOnFirstFailure)
                  .Length(0, 20).WithMessage("SubscriptionPlan lengh could not be greater than 20");

                RuleFor(x => x.Geolocation)
                 .Cascade(CascadeMode.StopOnFirstFailure)
                 .Length(0, 20).WithMessage("Geolocation lengh could not be greater than 20");
            }
        }


    }
}
