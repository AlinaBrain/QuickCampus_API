﻿using QuickCampus_DAL.Context;

namespace QuickCampus_Core.Interfaces
{
    public interface IApplicationUserRepo : IGenericRepository<ApplicationUser>
    {


    }
}
