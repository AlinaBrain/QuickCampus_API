﻿
namespace QuickCampus_Core.Interfaces
{
    public interface IStateRepo
    { 

    }
}
